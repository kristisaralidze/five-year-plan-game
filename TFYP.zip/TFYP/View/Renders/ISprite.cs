﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TFYP.View.Renders
{
    internal interface ISprite : IRenderable
    {
        Texture2D Texture { get; set; }
        Texture2D AltTexture { get; set; }
        Color Tint { get; set; }
        float Scale { get; set; }
    }
}
