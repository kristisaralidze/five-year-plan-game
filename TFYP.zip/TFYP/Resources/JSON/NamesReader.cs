﻿using MonoGame.Extended.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TFYP.Resources.JSON
{
    public class NamesReader : JsonContentTypeReader<NameList> { }
}
