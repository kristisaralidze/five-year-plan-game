﻿

using var game = new TFYP.Controller.TFYP();
game.Run();
